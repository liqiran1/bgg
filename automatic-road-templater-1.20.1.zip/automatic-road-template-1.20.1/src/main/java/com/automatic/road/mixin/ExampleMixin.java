package com.automatic.road.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerEntity.class)
public abstract class ExampleMixin {
    @Unique private boolean enabled = false;
    @Unique private long lastAction = 0;

    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        handleInput();
        if (enabled) performBuild();
    }

    @Unique
    private void handleInput() {
        if (MinecraftClient.getInstance().options.sprintKey.wasPressed()) {
            enabled = !enabled;
        }
    }

    @Unique
    private void performBuild() {
        ClientPlayerEntity player = MinecraftClient.getInstance().player;
        if (player == null || System.currentTimeMillis() - lastAction < 100) return;

        Vec3d look = player.getRotationVec(1.0F);
        BlockHitResult hit = player.world.raycast(new net.minecraft.world.RaycastContext(
            player.getEyePos(),
            player.getEyePos().add(look.multiply(4)),
            net.minecraft.world.RaycastContext.ShapeType.OUTLINE,
            net.minecraft.world.RaycastContext.FluidHandling.NONE,
            player
        ));

        if (hit.getType() == net.minecraft.util.hit.HitResult.Type.BLOCK) {
            BlockPos pos = hit.getBlockPos().offset(hit.getSide());
            player.swingHand(Hand.MAIN_HAND);
            player.networkHandler.sendPacket(
                new net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket(
                    Hand.MAIN_HAND,
                    hit,
                    player.world.getTime()
                )
            );
            lastAction = System.currentTimeMillis();
        }
    }
}