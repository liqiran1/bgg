package com.automatic.road

import net.fabricmc.api.ClientModInitializer

object AutomaticRoadClient : ClientModInitializer {
	override fun onInitializeClient() {
		// This entrypoint is suitable for setting up client-specific logic, such as rendering.
	}
}